package repository;

import model.Episode;
import model.TvSerie;

import java.time.LocalDate;
import java.util.ArrayList;

public interface TvSerieRepository {
    ArrayList<TvSerie> getTVSerier();

    TvSerie getTvSerie(String tvSerieId);

    ArrayList<Episode> getEpisoderISesong(String tvSerieTittel, int sesongNr);

    Episode getEpisode(String tvSerieTittel, int sesongNr, int episodeNr);

    void createEpisode(String tvserien, String tittel, String beskrivelse, String bildeUrl, int sesongNr, int episodeNr, int spilletid, LocalDate utgivelsesdato);
    void deleteEpisode(String tvserien, int sesongNr, int episodeNr);
    void updateEpisode(String tvserie, String tittel, String beskrivelse, String bildeURL, int sesongNr, int episodeNr, int spilletid, LocalDate utgivelsesdato);

}
