package repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import model.Episode;
import model.TvSerie;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;

public class TvSerieJSONRepository implements TvSerieRepository {
    private ArrayList<TvSerie> tvSerier;
    public TvSerieJSONRepository(String filename) {
        tvSerier = readFromJson(filename);
    }

    @Override
    public ArrayList<TvSerie> getTVSerier(){
        return new ArrayList<>(tvSerier);
    }
    @Override
    public TvSerie getTvSerie(String tvSerieId) {
        for (TvSerie tvSerie: tvSerier) {
            if (tvSerie.getTittel().equals(tvSerieId))
                return tvSerie;
        }

        return null;
    }

    @Override
    public ArrayList<Episode> getEpisoderISesong(String tvSerieTittel, int sesongNr) {
        return getTvSerie(tvSerieTittel).hentEpisoderISesong(sesongNr);

    }
    @Override
    public Episode getEpisode(String tvSerieTittel, int sesongNr, int episodeNr){
        return getTvSerie(tvSerieTittel).getEpisode(sesongNr, episodeNr);
    }

    @Override
    public void createEpisode(String tvserie, String tittel, String beskrivelse, String bildeUrl, int sesongNr, int episodeNr, int spilletid, LocalDate utgivelsesdato) {
        TvSerie tvSerie = getTvSerie(tvserie);
        Episode episode = new Episode(tittel, beskrivelse, episodeNr, sesongNr, spilletid, utgivelsesdato, bildeUrl);
        tvSerie.leggTilEpisode(episode);
        writeToJson("tvshows_10.json");

    }
    @Override
    public void deleteEpisode(String tvserie, int episodeNr, int sesongNr) {
        getTvSerie(tvserie).deleteEpisode(episodeNr,sesongNr);
        writeToJson("tvshows_10.json");
    }

    @Override
    public void updateEpisode(String tvserie, String tittel, String beskrivelse, String bildeURL, int sesongNr, int episodeNr, int spilletid, LocalDate utgivelsesdato) {
        getTvSerie(tvserie).updateEpisode(tittel, beskrivelse, bildeURL, sesongNr, episodeNr, spilletid, utgivelsesdato);
        writeToJson("tvshows_10.json");

    }

    public void writeToJson(String filename) {
        File fileJSON = new File(filename);
        Thread thread = new Thread(new Runnable() {
            public void run() {
                ObjectMapper objectmapper = new ObjectMapper();

                try {
                    objectmapper.registerModule(new JavaTimeModule());
                    objectmapper.writerWithDefaultPrettyPrinter().writeValue(fileJSON, tvSerier);
                } catch (IOException e) {
              throw new RuntimeException(e);
                }
            }

        });
        thread.start();
    }


    private static ArrayList<TvSerie> readFromJson(String filename) {
        ArrayList<TvSerie> returnTvSerieList = new ArrayList<>();

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule((new JavaTimeModule()));

        try {
            TvSerie[] TvSerieValue = objectMapper.readValue(new File(filename), TvSerie[].class);
            returnTvSerieList.addAll(Arrays.asList(TvSerieValue));

        } catch (IOException e) {
            e.printStackTrace();
        }
        return returnTvSerieList;

    }
}
