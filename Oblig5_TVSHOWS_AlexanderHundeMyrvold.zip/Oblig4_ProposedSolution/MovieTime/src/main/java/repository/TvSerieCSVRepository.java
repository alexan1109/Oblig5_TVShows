package repository;

import model.Episode;
import model.TvSerie;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;

public class TvSerieCSVRepository implements TvSerieRepository {

public HashMap<String, TvSerie> TvSerieMap = new HashMap<>();
public ArrayList<TvSerie> TvSerieList = new ArrayList<>();
private ArrayList<Episode> episoder;

    public TvSerieCSVRepository(String filename) {
        //HashMap<String, TvSerie> TvSeriesFromFile = readFromCSVFile(new File("tvshows_10.csv"));
        TvSerieMap = readFromCSVFile(new File("tvshows_10.csv"));
        System.out.println(TvSerieMap);
        }

    @Override
    public ArrayList<TvSerie> getTVSerier() {
        ArrayList<TvSerie> returnList = new ArrayList<>();

        return new ArrayList<>(returnList);
    }

    @Override
    public TvSerie getTvSerie(String tvSerieTittel) {
        ArrayList<TvSerie> TvSeriesEntry = new ArrayList<>(TvSerieMap.values());

       /* for (Map.Entry<String, TvSerie> entry : TvSerieMap.entrySet()) {
            if (entry.getKey().equals(tvSerieTittel))
                return TvSerieMap;
        }*/

        return null;
    }

    @Override
    public ArrayList<Episode> getEpisoderISesong(String tvSerieTittel, int sesongNr) {
        return getTvSerie(tvSerieTittel).hentEpisoderISesong(sesongNr);

    }

    public Episode getEpisode(String tvSerieTittel, int sesongNr, int episodeNr) {
        return getTvSerie(tvSerieTittel).getEpisode(sesongNr, episodeNr);
    }

    @Override
    public void createEpisode(String tvserien, String tittel, String beskrivelse, String bildeUrl, int sesongNr, int episodeNr, int spilletid, LocalDate utgivelsesdato) {

    }

    @Override
    public void deleteEpisode(String tvserien, int sesongNr, int episodeNr) {

    }

    @Override
    public void updateEpisode(String tvserie, String tittel, String beskrivelse, String bildeURL, int sesongNr, int episodeNr, int spilletid, LocalDate utgivelsesdato) {
    }


    private static HashMap<String, TvSerie> readFromCSVFile(File filename) {
        HashMap<String, TvSerie> TvSerier = new HashMap<>();
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] values = line.split(";");

                   if (TvSerier.containsKey(values[0])) {
                        TvSerie Tvserie = TvSerier.get(values[0]);
                        Tvserie.getEpisoder().add(new Episode(values[4], values[5], Integer.parseInt(values[6]), Integer.parseInt(values[7]), Integer.parseInt(values[8])));

                    } else {
                       TvSerie t = new TvSerie(values[0], values[1], java.time.LocalDate.parse(values[2]), values[3]);
                       t.getEpisoder().add(new Episode(values[4], values[5], Integer.parseInt(values[6]), Integer.parseInt(values[7]), Integer.parseInt(values[8])));
                       TvSerier.put(t.getTittel(), t);
                    }

            }

        } catch (IOException e) {
            System.out.println(e);
        }
        return TvSerier;

    }
}
