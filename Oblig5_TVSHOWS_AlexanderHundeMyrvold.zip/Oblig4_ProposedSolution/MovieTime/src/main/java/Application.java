import controller.EpisodeController;
import controller.TvSerieController;
import io.javalin.Javalin;
import io.javalin.http.Context;
import io.javalin.http.Handler;
import io.javalin.vue.VueComponent;
import org.jetbrains.annotations.NotNull;
import repository.TvSerieCSVRepository;
import repository.TvSerieDataRepository;
import repository.TvSerieJSONRepository;
import repository.TvSerieRepository;

public class Application {
    public static void main(String[] args) {
        Javalin app = Javalin.create(config -> {
            config.staticFiles.enableWebjars();
            config.vue.vueAppName = "app";
        }).start(8100);

        app.before("/", ctx -> ctx.redirect("/tvserie"));

        app.get("/tvserie", new VueComponent("tvserie-overview"));
        app.get("/tvserie/{tvserie-id}/sesong/{sesong-nr}", new VueComponent("tvserie-detail"));
        app.get("/tvserie/{tvserie-id}/sesong/{sesong-nr}/episode/{episode-nr}", new VueComponent("episode-detail"));
        app.get("/tvserie/{tvserie-id}/createepisode", new VueComponent("episode-create"));
        app.get("/tvserie/{tvserie-id}/sesong/{sesong-nr}/episode/{episode-nr}/updateepisode", new VueComponent("episode-update"));


        TvSerieRepository tvSerieRepository = new TvSerieJSONRepository("tvshows_10.json");
        //TvSerieRepository tvSerieRepository = new TvSerieCSVRepository("tvshows_10.csv");
        TvSerieController tvSerieController = new TvSerieController(tvSerieRepository);
        EpisodeController episodeController = new EpisodeController(tvSerieRepository);

        app.get("api/tvserie", new Handler() {
            @Override
            public void handle(Context ctx) throws Exception {
                tvSerieController.getAlleTvSerier(ctx);
            }
        });

        app.get("api/tvserie/{tvserie-id}", context -> tvSerieController.getTVSerie(context));

        app.post("/api/tvserie/{tvserie-id}/createepisode", new Handler() {
            @Override
            public void handle(@NotNull Context context) {
                episodeController.createEpisodeController(context);

            }
        });
        app.post("/api/tvserie/{tvserie-id}/sesong/{sesong-nr}/episode/{episode-nr}/updateepisode", new Handler() {
            @Override
            public void handle(@NotNull Context context) {
                episodeController.updateEpisodeController(context);
            }
        });

        app.post("/api/tvserie/{tvserie-id}/sesong/{sesong-nr}/episode/{episode-nr}/deleteepisode", new Handler() {
            @Override
            public void handle(@NotNull Context context) {
                episodeController.deleteEpisodeController(context);
            }
        });

        app.get("api/tvserie/{tvserie-id}/sesong/{sesong-nr}", episodeController::getEpisoderISesong);
        app.get("api/tvserie/{tvserie-id}/sesong/{sesong-nr}/episode/{episode-nr}", episodeController::getEpisode);
        app.get("api/tvserie/{tvserie-id}/sesong/{sesong-nr}/episode/{episode-nr}/deleteepisode", episodeController::deleteEpisodeController);

    }
}